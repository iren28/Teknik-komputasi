%Membuat program menghitung integral luas daerah yang dibatasi oleh f(X)=y
%Menggunakan metode numerik

a=1;
while a<=6
    clear all;
    clc;
    fprintf('\n\n')
    disp('====================================')
    disp('        INTERGRASI NUMERIK          ')
    disp('Menghitung Luas Daerah yang dibatasi')
    disp('             F(x) = 3*X^2           ')
    disp('                oleh                ')
    disp('             Iren B Pasu            ')
    disp('              23118008              ')
    disp('====================================')
    disp('Menggunakan METODE NUMERIK   :     ')
    disp('   1.Metode Reimann')
    disp('   2.Metode Trapezoida')
    disp('   3.Metode Simpson 1/3')
    disp('   4.Metode Simpson 3/8')
    disp('   5.Metode Kuadratur Gauss 2 titik')
    disp('   6.Metode Kuadratur Gauss 3 titik')
    disp('   7.Keluar')
    a=input('\n   Pilih Metode Yang Ingin Digunakan : ');
    
    if a == 1
        fprintf('\n\n====================================')
        fprintf('\n           METODE REINMANN          ')
        fprintf('\n====================================')
        %Diketahui :
    
        %Nilai  f(X);
        fprintf('\nFungsi y= f(X)        = 3*x.^2 ');
        %masukan batas bawah
        a=input('\nBatas bawah (a)       = ');

        %masukan batas atas
        b=input('Batas atas (b)        = ');

        %masukan jumlah pembagi
        n=input('Jumlah Pembagi (n)    = ');
    
        % Ditanya : menghitung luas daerah yang dibatas menggunakan metode reimann ?

        %Dijawab :

        %Menghitung H
        h=(b-a)/n;        
        fprintf('Hitung\th = (b-a)/n ');
        fprintf('\n\t\th = %g ',h);
        
        %Menghitung jumlah fxi
        fprintf('\n--------------------------')
        fprintf('\n         TABEL            ')
        fprintf('\n--------------------------')
        fprintf('\n\t   Xi   \tF(X)\n');
         
        s=0;
        k=s+1;
        for i=s:k:n	   
           x =[a:h:b];% untuk menghitung fxi yang berawal dari a sampai dengan fxi 
           y=3*x.^2;  %yang berakhir di b yang berakhir di b
        end
        tabel(:,1)=x'; %untuk menampilkan x dan y dalam bentuk tabel
        tabel(:,2)=y';
        disp (tabel)
        fprintf('---------------------------')
       
        %Total jumlah fxi =
        fprintf('\nJumlah fxi = %g',sum(y))
        fprintf('\nRumus Luas Menggunakan Metode Reiman = h*f(xi)')

        %Menghitung Luas daerah yang dibatasi F(x) Metode Reimann
        fprintf('\n\nLuas Daerah yang dibatasi menggunakan : ')
        fprintf('\n   *  Menggunakan Metode Reimann    = ')
        I_Reimann=h*sum(y);
        fprintf('%g',I_Reimann);


        %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
       fprintf('\n   *  Secara kalkulus               = ')
       m = inline('(3*x.^2)');
       s=quad(m,a,b);
       fprintf('%.3f',s);

        %Error 
       fprintf('\n   *  Error                         = ') 
       e = I_Reimann-s;
       fprintf('%.3f',e);
       fprintf('\n   *  Persen Error                  = ')
       persen= (e/s)*100;
       fprintf('%.3f Persen',persen);
       
       
         %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_Reimann)]);
        grid on
       
       break;
       
        
    elseif a == 2
        fprintf('\n\n====================================')
        fprintf('\n           METODE TRAPEZOIDA         ')
        fprintf('\n====================================')

        %Diketahui=
        fprintf('\nFungsi F(X)            = 3x^2 ');
        a=input('\nBatas bawah (a)        = ');
        b=input('Batas atas   (b)       = ');
        n=input('Jumlah Pembagi (n)     = ');
        
        %Ditanya=Luas daerah yang dibatasi menggunakan metode Trapezoida ?
    
        %Dijawab=
        %Menghitung H
        fprintf(' Hitung h\t= (b-a)/n ')
        h=(b-a)/n;
        fprintf(' \n\t\th\t= %g ',h);

        %Menghitung jumlah fxi
        fprintf('\n\n----------------------\n')
        fprintf('       TABEL          \n')
        fprintf('----------------------\n')
        fprintf('\t Xi\t F(X)\n')
            s=0;
            k=s+1;
            for i=s:k:n	
                x =a:h:b;
                y=3*x.^2;  

                if(i>1 & i<n) %menghitung jumlah fxi
                    Jumlah=sum(y)-y(1)-y(n+1);
                end     
            end
         tabel(:,1)=x'; %untuk menampilkan x dan y dalam bentuk tabel
         tabel(:,2)=y';
         disp (tabel)
         fprintf('---------------------')
  
         fprintf('\nf(0) = %g',y(1)); 
         fprintf('\nf(n) = %g',y(n+1));
         fprintf('\nJumlah fxi+h = %g',Jumlah)

        %rumus luas menggunakan metode trapezoida
        fprintf('\n\nLuas = h/2* [f(0)+2*(fxi+h)+fn] ');
        fprintf('\n\nLuas Daerah yang dibatasi menggunakana :');
        fprintf('\n   *  Menggunakan Metode Trapezoida = ');
        I_trap = (h/2)*(y(1)+ (2*Jumlah) + y(n+1)); %rumus trapezoida
        fprintf(' %g',I_trap)

        %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n   *  Secara kalkulus               = ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

        %Error 
        fprintf('\n   *  Error                         = ') 
        e = I_trap-s;
        fprintf('%.3f',e);
        fprintf('\n   *  Persen Error                  = ')
        persen= (e/s)*100;
        fprintf('%.3f Persen ',persen);

        %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_trap)]);
        grid on
        break;
        
    elseif a == 3
        fprintf('\n\n====================================')
        fprintf('\n           METODE SIMPSON 1/3       ')
        fprintf('\n====================================')

        %Diketahui
        fprintf('\nFungsi F(X)             = 3x^2 ');
        a=input('\nBatas bawah             = ');
        b=input('Batas atas              = ');
        n=input('Jumlah Pembagi (n)      = ');

        %Menghitung H
        fprintf('Hitung  h = (b-a)/n ')
        h=(b-a)/n;
        fprintf('\n\t\th = %g ',h);

        %Menghitung jumlah fxi
        fprintf('\n---------------------\n')
        fprintf('      TABEL          \n')
        fprintf('---------------------\n')
        fprintf('\t Xi\t F(X)\n')
        s=0;
        k=s+1;       
        for i=s:k:n	
         x =a:h:b;
         y=3*x.^2;   
        end
        tabel(:,1)=x';%untuk menampilkan x dan y dalam bentuk tabel
        tabel(:,2)=y';
        disp (tabel)
        fprintf('----------------------')
  
        fprintf('\nf(0) = %g',y(1)); 
        fprintf('\nf(n) = %g',y(n+1));
        f=inline('3*xi.^2');
        xi=[a:h:b];
        fganjil=sum(f(xi(2:2:end)));
        fgenap=sum(f(xi(3:2:end-2)));
        fprintf('\nJumlahfxiGanjil = %g',fganjil); 
        fprintf('\nJumlahfxiGenap = %g',fgenap);
        fprintf('\n\nLuas = h/3* [f(0)+4*JumlahfxiGanjil+2*JumlahfxiGenap+fn] ')

        %Menghitung Luas daerah yang dibatasi F(x)
        fprintf('\n\n-------Luas Daerah yang dibatasi-------- ')
        fprintf('\n\t* Menggunakan Metode Simpson 1/3 = ')
        I_simpson = h/3*(f(xi(1))+ 4*fganjil+2*fgenap + f(xi(end)));
        fprintf(' %g',I_simpson);
     
        %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n    *  Secara kalkulus               = ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);
   
        %Error 
        fprintf('\n    *  Error                         = ') 
        e = I_simpson-s;
        fprintf('%.3f',e);
        fprintf('\n    *  Persen Error                  = ')
        persen= abs((e/s)*100);
        fprintf('%.3f Persen',persen);
 
        %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_simpson)]);
        grid on
        break;
        
    elseif a == 4
        fprintf('\n\n====================================')
        fprintf('\n           METODE SIMPSON 3/8       ')
        fprintf('\n====================================')

        %Diketahui
        fprintf('\nFungsi F(X)             = 3x^2 ');
        a=input('\nBatas bawah             = ');
        b=input('Batas atas              = ');

        %Ditanya : Hitung luas daerah yang dibatasi f(x) menggunakan metode simpson 3/8?
        %Dijawab :

        %Menghitung H
        fprintf('Hitung  h = (b-a)/3 ');
        h=(b-a)/3;
        fprintf('\n\t\th = %g ',h);

        %Menghitung jumlah fxi
        fprintf('\n\n----------------------\n')
        fprintf('       TABEL\n')
        fprintf('----------------------\n')
        fprintf('\t   Xi\t  F(X)\n')
            s=0;
            k=s+1;
            for i=s:k:3	
                x =a:h:b;
                y=3*x.^2;    
                w=sum(y);  
            end
         tabel(:,1)=x'; %untuk menampilkan x dan y dalam bentuk tabel
         tabel(:,2)=y';
         disp (tabel)
         fprintf('-----------------------')
  
         fprintf('\nf(0) = %g',y(1)); 
         fprintf('\nf(1) = %g',y(2));
         fprintf('\nf(2)= %g',y(3));
         fprintf('\nf(3) = %g',y(3+1));
        fprintf('\n\nLuas = 3h/8* [f(0)+3*(fx1)+3*f(X2)+f(x3)] ')

        %Menghitung Luas daerah yang dibatasi F(x)
        fprintf('\n\n-------Luas Daerah yang dibatasi-------')
        fprintf('\n   *  Menggunakan Metode Simpson 3/8 =')
        I_simpson = (3/8)*h*(y(1)+ (3*y(2))+(3*y(3)) + y(3+1));
        fprintf(' %g',I_simpson)

        %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n   *  Secara kalkulus               = ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

        %Error 
        fprintf('\n   *  Error                         = ') 
        e = I_simpson-s;
        fprintf('%.3f',e);
        fprintf('\n   *  Persen Error                  = ')
        persen= (e/s)*100;
        fprintf('%.3f Persen',persen);
        
        %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_simpson)]);
        grid on
        break;
        
    elseif a == 5
       fprintf('\n\n====================================')
        fprintf('\n   METODE KUADRATUR GAUSS 2 TITIK    ')
        fprintf('\n====================================')

        %Diketahui=
        fprintf('\nFungsi F(X)            = 3x^2 ');
        a=input('\nBatas bawah (a)        = ');
        b=input('Batas atas   (b)       = ');
        
        %Ditanya=Luas daerah yang dibatasi menggunakan metode Kuadratur Gauss 2 titik ?
    
        %Dijawab=
        %Menghitung nilai konversi variabel :
        fprintf('\n* Nilai Konversi variabel :\n');
        fprintf(' \t x = 1/2*(b-a)u+1/2(b+a) \n');
         m=(b-a)/2;
         n=(b+2)/2;
        fprintf(' \t x = %gu + %g',m,n);
        u1=-1/sqrt(3);
        u2=1/sqrt(3);
        
        %Menentukan fungsi g(u) dengan  :
        fprintf('\n* Tentukan fungsi g(u) :\n');
        fprintf('\tg(u) = 1/2(b-a) * f(1/2*(b-a)*u+ 1/2(b+a))');
        k=m*3; % 3 di ambil dri fungsi f(X)=y= 3*X^2
        fprintf('\n\tg(u) = %g*(%g u + %g)^2\n',k,m,n); 
        
        %Menentukan fungsi g(0,5574) dengan  :  
        %f(x) = y=3*x.^2;
        gu1=m*3*(((m*u1)+n)^2); %g(-0,5574)
        gu2=m*3*(((m*u2)+n)^2); %g(0,5574)
        fprintf('\n* Hitung luas :');
        fprintf('\n\tLuas = g(-0,5774)+g(0,5774)');
        fprintf('\n\n\tg(-0,5774) = %g \n',gu1);
        fprintf('\tg(0,5774) = %g \n',gu2);
        
        %Menghitung Luas daerah yang dibatasi F(x)
        fprintf('\n\n-------Luas Daerah yang dibatasi-------')   
        L=gu1+gu2;
        fprintf('\n\t*  Menggunakan Metode Kuadratur 2 titik = %g ',L);
         
        %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n    *  Secara kalkulus               \t\t= ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

   
        %Error 
        fprintf('\n    *  Error                         \t\t= ') 
        e = L-s;
        fprintf('%.3f',e);
        fprintf('\n    *  Persen Error                  \t\t= ')
        persen= ((L)/s)*100;
        fprintf('%.3f Persen',persen);
        break;
        
        elseif a == 6
     
        fprintf('\n\n====================================')
        fprintf('\n   METODE KUADRATUR GAUSS 3 TITIK    ')
        fprintf('\n====================================')
        %Diketahui=
        fprintf('\nFungsi F(X)            = 3x^2 ');
        a=input('\nBatas bawah (a)        = ');
        b=input('Batas atas   (b)       = ');
        
        %Ditanya=Luas daerah yang dibatasi menggunakan metode Kuadratur Gauss 2 titik ?
    
        %Dijawab=
        %Menghitung nilai konversi variabel :
        fprintf('\n* Nilai Konversi variabel :\n');
        fprintf(' \t x = 1/2*(b-a)u+1/2(b+a) \n');
         m=(b-a)/2;
         n=(b+2)/2;
        fprintf(' \t x = %gu + %g',m,n);
        u1=-sqrt(3/5);
        u2=sqrt(3/5);
        u0=0;
        %Menentukan fungsi g(u) dengan  :
        fprintf('\n* Tentukan fungsi g(u) :\n');
        fprintf('\tg(u) = 1/2(b-a) * f(1/2*(b-a)*u+ 1/2(b+a))');
        k=m*3; % 3 di ambil dri fungsi f(X)=y= 3*X^2
        fprintf('\n\tg(u) = %g*(%g u + %g)^2\n',k,m,n); 
        
        %Menentukan fungsi g(0,5574) dengan  :  
        %f(x) = y=3*x.^2;
        gu0=m*3*(((m*u0)+n)^2);
        gu1=m*3*(((m*u1)+n)^2); %g(-0,5574)
        gu2=m*3*(((m*u2)+n)^2); %g(0,5574)
        fprintf('\n* Hitung luas :');
        fprintf('\n\tLuas = 8/9*g(0)+(5/9*g(-0,7746))+(5/9*g(0,7746))');
        fprintf('\n\n\tg(0) \t\t= %g \n',gu0);
        fprintf('\tg(-0,7746)  = %g \n',gu1);
        fprintf('\tg(0,7746)   = %g \n',gu2);
        
        %Menghitung Luas daerah yang dibatasi F(x)
        fprintf('\n\n-------Luas Daerah yang dibatasi-------')   
        L=8/9*gu0+(5/9*gu1)+(5/9*gu2);
        fprintf('\n\t*  Menggunakan Metode Kuadratur 2 titik = %g ',L);
         
        %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n    *  Secara kalkulus               \t\t= ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

        %Error 
        fprintf('\n    *  Error                         \t\t= ') 
        e = L-s;
        fprintf('%.3f',e);
        fprintf('\n    *  Persen Error                  \t\t= ')
        persen= ((L)/s)*100;
        fprintf('%.3f Persen',persen);
        break;
        
    elseif a==7
        break;
    end
    
end
fprintf('\n\n------Terima Kasih------');

