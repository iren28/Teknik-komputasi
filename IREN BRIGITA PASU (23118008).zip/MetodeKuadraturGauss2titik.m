%Membuat program menghitung integral luas daerah yang dibatasi oleh f(X)=y
%Menggunakan metode Kuadratur Gauss 2 titik
clc,clear

disp('====================================')
disp('        INTERGRASI NUMERIK          ')
disp('Menghitung Luas Daerah yang dibatasi')
disp('            Menggunakan             ')
disp('  METODE KUADRATUR GAUSS 2 TITIK    ')
disp('               oleh                 ')
disp('          Iren Brigita Pasu         ')
disp('              23118008              ')
disp('====================================')

 %Diketahui=
        fprintf('\nFungsi F(X)            = 3x^2 ');
        a=input('\nBatas bawah (a)        = ');
        b=input('Batas atas   (b)       = ');
        
 %Ditanya=Luas daerah yang dibatasi menggunakan metode Kuadratur Gauss 2 titik ?
    
    %Dijawab=
    %Menghitung nilai konversi variabel :
        fprintf('\n* Nilai Konversi variabel :\n');
        fprintf(' \t x = 1/2*(b-a)u+1/2(b+a) \n');
         m=(b-a)/2;
         n=(b+2)/2;
        fprintf(' \t x = %gu + %g',m,n);
        u1=-1/sqrt(3);
        u2=1/sqrt(3);
        
     %Menentukan fungsi g(u) dengan  :
        fprintf('\n* Tentukan fungsi g(u) :\n');
        fprintf('\tg(u) = 1/2(b-a) * f(1/2*(b-a)*u+ 1/2(b+a))');
        k=m*3; % 3 di ambil dri fungsi f(X)=y= 3*X^2
        fprintf('\n\tg(u) = %g*(%g u + %g)^2\n',k,m,n); 
        
     %Menentukan fungsi g(0,5574) dengan  :  
        %f(x) = y=3*x.^2;
        gu1=m*3*(((m*u1)+n)^2); %g(-0,5574)
        gu2=m*3*(((m*u2)+n)^2); %g(0,5574)
        fprintf('\n* Hitung luas :');
        fprintf('\n\tLuas = g(-0,5774)+g(0,5774)');
        fprintf('\n\n\tg(-0,5774) = %g \n',gu1);
        fprintf('\tg(0,5774) = %g \n',gu2);
        
     %Menghitung Luas daerah yang dibatasi F(x)
        fprintf('\n\n-------Luas Daerah yang dibatasi-------')   
        L=gu1+gu2;
        fprintf('\n\t*  Menggunakan Metode Kuadratur 2 titik = %g ',L);
         
    %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n    *  Secara kalkulus               \t\t= ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

   
    %Error 
        fprintf('\n    *  Error                         \t\t= ') 
        e = L-s;
        fprintf('%.3f',e);
        fprintf('\n    *  Persen Error                  \t\t= ')
        persen= (e/s)*100;
        fprintf('%.3f Persen',persen);
        

         
         
         
         