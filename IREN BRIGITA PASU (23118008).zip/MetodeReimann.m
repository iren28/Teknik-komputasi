%Membuat program menghitung integral luas daerah yang dibatasi oleh f(X)=y
%Menggunakan metode reimann
clear all;
clc;

disp('====================================')
disp('        INTERGRASI NUMERIK          ')
disp('Menghitung Luas Daerah yang dibatasi')
disp('            Menggunakan             ')
disp('           METODE REINMANN          ')
disp('                oleh                ')
disp('             Iren B Pasu            ')
disp('              23118008              ')
disp('====================================')
%Diketahui :
    
    %Nilai  f(X);
     fprintf('\nFungsi y= f(X)        = 3*x.^2 ');
    %masukan batas bawah
        a=input('\nBatas bawah (a)       = ');

    %masukan batas atas
        b=input('Batas atas (b)        = ');

    %masukan jumlah pembagi
        n=input('Jumlah Pembagi (n)    = ');
    
    % Ditanya : menghitung luas daerah yang dibatas menggunakan metode reimann ?

    %Dijawab :

    %Menghitung H
        h=(b-a)/n;        
        fprintf('Hitung\th = (b-a)/n ');
        fprintf('\n\t\th = %g ',h);
        
    %Menghitung jumlah fxi
        fprintf('\n--------------------------')
        fprintf('\n         TABEL            ')
        fprintf('\n--------------------------')
        fprintf('\n\t   Xi   \tF(X)\n');
         
        s=0;
        k=s+1;
        for i=s:k:n	   
           x =[a:h:b];% untuk menghitung fxi yang berawal dari a sampai dengan fxi 
           y=3*x.^2;  %yang berakhir di b yang berakhir di b
        end
        tabel(:,1)=x'; %untuk menampilkan x dan y dalam bentuk tabel
        tabel(:,2)=y';
        disp (tabel)
        fprintf('---------------------------')
       
    %Total jumlah fxi =
        fprintf('\nJumlah fxi = %g',sum(y))
        fprintf('\nRumus Luas Menggunakan Metode Reiman = h*f(xi)')

    %Menghitung Luas daerah yang dibatasi F(x) Metode Reimann
        fprintf('\n\nLuas Daerah yang dibatasi menggunakan : ')
        fprintf('\n   *  Menggunakan Metode Reimann    = ')
        I_Reimann=h*sum(y);
        fprintf('%g',I_Reimann);


    %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
       fprintf('\n   *  Secara kalkulus               = ')
       m = inline('(3*x.^2)');
       s=quad(m,a,b);
       fprintf('%.3f',s);

    %Error 
       fprintf('\n   *  Error                         = ') 
       e = I_Reimann-s;
       fprintf('%.3f',e);
       fprintf('\n   *  Persen Error                  = ')
       persen= (e/s)*100;
       fprintf('%.3f Persen',persen);
       
    %Gambar grafik
        plot(x,y);
        title(['Luas Daerah dibawah kurva ',num2str(I_Reimann)]);
        grid on
    

