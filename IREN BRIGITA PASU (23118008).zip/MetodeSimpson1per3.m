%Membuat program menghitung integral luas daerah yang dibatasi oleh f(X)=y
%Menggunakan metode Simpson
clc,clear

disp('====================================')
disp('        INTERGRASI NUMERIK          ')
disp('Menghitung Luas Daerah yang dibatasi')
disp('            Menggunakan             ')
disp('         METODE SIMPSON 1/3         ')
disp('                oleh                ')
disp('         Iren Brigita Pasu          ')
disp('              23118008              ')
disp('====================================')

%Diketahui
fprintf('\nFungsi F(X)             = 3x^2 ');
a=input('\nBatas bawah             = ');
b=input('Batas atas              = ');
n=input('Jumlah Pembagi (n)      = ');

  %Menghitung H
     fprintf('Hitung  h = (b-a)/n ')
     h=(b-a)/n;
     fprintf('\n\t\th = %g ',h);

   %Menghitung jumlah fxi
     fprintf('\n---------------------\n')
     fprintf('      TABEL          \n')
     fprintf('---------------------\n')
     fprintf('\t Xi\t F(X)\n')
     s=0;
     k=s+1;       
     for i=s:k:n	
         x =a:h:b;
         y=3*x.^2;   
     end
     tabel(:,1)=x';%untuk menampilkan x dan y dalam bentuk tabel
     tabel(:,2)=y';
     disp (tabel)
     fprintf('----------------------')
  
     fprintf('\nf(0) = %g',y(1)); 
     fprintf('\nf(n) = %g',y(n+1));
     f=inline('3*xi.^2');
     xi=[a:h:b];
     fganjil=sum(f(xi(2:2:end)));
     fgenap=sum(f(xi(3:2:end-2)));
     fprintf('\nJumlahfxiGanjil = %g',fganjil); 
     fprintf('\nJumlahfxiGenap = %g',fgenap);
     fprintf('\n\nLuas = h/3* [f(0)+4*JumlahfxiGanjil+2*JumlahfxiGenap+fn] ')

     %Menghitung Luas daerah yang dibatasi F(x)
     fprintf('\n\n-------Luas Daerah yang dibatasi-------- ')
     fprintf('\n\t* Menggunakan Metode Simpson 1/3 = ')
     I_simpson = h/3*(f(xi(1))+ 4*fganjil+2*fgenap + f(xi(end)));
     fprintf(' %g',I_simpson);
     
    %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
     fprintf('\n    *  Secara kalkulus               = ')
     m = inline('(3*x.^2)');
     s=quad(m,a,b);
     fprintf('%.3f',s);
     
    %Error 
        fprintf('\n    *  Error                         = ') 
        e = I_simpson-s;
        fprintf('%.3f',e);
        fprintf('\n    *  Persen Error                  = ')
        persen= abs((e/s)*100);
        fprintf('%.3f Persen',persen);
 
    %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_simpson)]);
        grid on