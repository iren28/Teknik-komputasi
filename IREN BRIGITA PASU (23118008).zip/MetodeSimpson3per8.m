%Membuat program menghitung integral luas daerah yang dibatasi oleh f(X)=y
%Menggunakan metode Simpson 
clc,clear

disp('====================================')
disp('        INTERGRASI NUMERIK          ')
disp('Menghitung Luas Daerah yang dibatasi')
disp('            Menggunakan             ')
disp('         METODE SIMPSON 3/8         ')
disp('                oleh                ')
disp('         Iren Brigita Pasu          ')
disp('              23118008              ')
disp('====================================')

%Diketahui
fprintf('\nFungsi F(X)             = 3x^2 ');
a=input('\nBatas bawah             = ');
b=input('Batas atas              = ');

%Ditanya : Hitung luas daerah yang dibatasi f(x) menggunakan metode simpson 3/8?
%Dijawab :

  %Menghitung H
        fprintf('Hitung  h = (b-a)/3 ');
        h=(b-a)/3;
        fprintf('\n\t\th = %g ',h);

    %Menghitung jumlah fxi
        fprintf('\n\n----------------------\n')
        fprintf('       TABEL\n')
        fprintf('----------------------\n')
        fprintf('\t   Xi\t  F(X)\n')
            s=0;
            k=s+1;
            for i=s:k:3	
                x =a:h:b;
                y=3*x.^2;    
                w=sum(y);  
            end
         tabel(:,1)=x'; %untuk menampilkan x dan y dalam bentuk tabel
         tabel(:,2)=y';
         disp (tabel)
         fprintf('-----------------------')
  
         fprintf('\nf(0) = %g',y(1)); 
         fprintf('\nf(1) = %g',y(2));
         fprintf('\nf(2)= %g',y(3));
         fprintf('\nf(3) = %g',y(3+1));
        fprintf('\n\nLuas = 3h/8* [f(0)+3*(fx1)+3*f(X2)+f(x3)] ')

    %Menghitung Luas daerah yang dibatasi F(x)
        fprintf('\n\n-------Luas Daerah yang dibatasi-------')
        fprintf('\n   *  Menggunakan Metode Simpson 3/8 =')
        I_simpson = (3/8)*h*(y(1)+ (3*y(2))+(3*y(3)) + y(3+1));
        fprintf(' %g',I_simpson)

    %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n   *  Secara kalkulus               = ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

   
    %Error 
        fprintf('\n   *  Error                         = ') 
        e = I_simpson-s;
        fprintf('%.3f',e);
        fprintf('\n   *  Persen Error                  = ')
        persen= (e/s)*100;
        fprintf('%.3f Persen',persen);
        
     %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_simpson)]);
        grid on
