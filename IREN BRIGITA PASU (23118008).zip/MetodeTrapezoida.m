%Membuat program menghitung integral luas daerah yang dibatasi oleh f(X)=y
%Menggunakan metode Trapezoida
clc,clear

disp('====================================')
disp('        INTERGRASI NUMERIK          ')
disp('Menghitung Luas Daerah yang dibatasi')
disp('            Menggunakan             ')
disp('         METODE TRAPEZOIDA          ')
disp('               oleh                 ')
disp('          Iren Brigita Pasu         ')
disp('              23118008              ')
disp('====================================')

    %Diketahui=
        fprintf('\nFungsi F(X)            = 3x^2 ');
        a=input('\nBatas bawah (a)        = ');
        b=input('Batas atas   (b)       = ');
        n=input('Jumlah Pembagi (n)     = ');
        
    %Ditanya=Luas daerah yang dibatasi menggunakan metode Trapezoida ?
    
    %Dijawab=
    %Menghitung H
        fprintf(' Hitung h\t= (b-a)/n ')
        h=(b-a)/n;
        fprintf(' \n\t\th\t= %g ',h);

    %Menghitung jumlah fxi
        fprintf('\n\n----------------------\n')
        fprintf('       TABEL          \n')
        fprintf('----------------------\n')
        fprintf('\t Xi\t F(X)\n')
            s=0;
            k=s+1;
            for i=s:k:n	
                x =a:h:b;
                y=3*x.^2;  

                if(i>1 & i<n) %menghitung jumlah fxi
                    Jumlah=sum(y)-y(1)-y(n+1);
                end     
            end
         tabel(:,1)=x'; %untuk menampilkan x dan y dalam bentuk tabel
         tabel(:,2)=y';
         disp (tabel)
         fprintf('---------------------')
  
         fprintf('\nf(0) = %g',y(1)); 
         fprintf('\nf(n) = %g',y(n+1));
         fprintf('\nJumlah fxi+h = %g',Jumlah)

    %rumus luas menggunakan metode trapezoida
        fprintf('\n\nLuas = h/2* [f(0)+2*(fxi+h)+fn] ');
        fprintf('\n\nLuas Daerah yang dibatasi menggunakana :');
        fprintf('\n   *  Menggunakan Metode Trapezoida = ');
        I_trap = (h/2)*(y(1)+ (2*Jumlah) + y(n+1)); %rumus trapezoida
        fprintf(' %g',I_trap)

    %Menghitung Luas daerah yang dibatasi F(x) secara kalkulus
        fprintf('\n   *  Secara kalkulus               = ')
        m = inline('(3*x.^2)');
        s=quad(m,a,b);
        fprintf('%.3f',s);

   
    %Error 
        fprintf('\n   *  Error                         = ') 
        e = I_trap-s;
        fprintf('%.3f',e);
        fprintf('\n   *  Persen Error                  = ')
        persen= (e/s)*100;
        fprintf('%.3f Persen ',persen);


    %Gambar grafik
        plot(x,y)
        title(['Luas Daerah dibawah kurva ',num2str(I_trap)]);
        grid on